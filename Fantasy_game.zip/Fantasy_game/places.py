class Places:

    def __init__(self, description):
        self.description = description
        self.heroes = []
        self.direction = {"sever": None,
                          "vychod": None,
                          "jih": None,
                          "zapad": None}

    def umisti(self, sever, vychod, jih, zapad):
        self.direction["sever"] = sever
        self.direction["vychod"] = vychod
        self.direction["jih"] = jih
        self.direction["zapad"] = zapad

    def pridej_hrdinu(self, hrdina):
        self.heroes.append(hrdina)

    def odeber_hrdinu(self, hrdina):
        self.heroes.remove(hrdina)

    def je_tady_nekdo(self):
        return self.heroes