class Hero:
    pocet_bytosti = 0

    def __init__(self, name, race, place, job, health):
        self.name = name
        self.race = race
        self.job = job
        self.health = health
        Hero.pocet_bytosti += 1
        self.id = Hero.pocet_bytosti

        # umístění hrdiny do určitého místa
        self.place = place
        place.pridej_hrdinu(self)

    def kde_jsi(self):
        print("Hrdina", self.name, "je u", self.place.description)

    def jdi_na(self, smer):
        if self.place.direction[smer] is not None:
            self.place.odeber_hrdinu(self)
            self.place = self.place.direction[smer]
            self.place.pridej_hrdinu(self)
        else:
            print("Tímto směrem se nedá jít.")

#konverzace
    def setkat_se(self):
        ostatni_hrdinove = [hrdina for hrdina in self.place.je_tady_nekdo() if hrdina != self]
        if ostatni_hrdinove:
            for hrdina in ostatni_hrdinove:
                print("Hrdina", self.name, "a", hrdina.name, "se potkali u", self.place.description)
                print("  ")
                
                print("Vyberte číslo pro konverzaci:")
                print("1 - Jak se máš?")
                print("2 - Ptejte se na úkoly.")
                
                volba = int(input("Zadejte číslo (1-2): "))
                
                # Reakce podle výběru
                if volba == 1:
                    print(self.name, "se ptá: 'Jak se máš,", hrdina.name)
                    print(hrdina.name,"odpověděl:", "Mám se dobře, a co ty?", self.name)
                elif volba == 2:
                    print(self.name, "se ptá: 'Jakej máš úkol?", hrdina.name)
                    print(hrdina.name, "odpověděl: 'Nemám žádnej", self.name)
                else:
                    print(self.name, "a", hrdina.name, "koukají na sebe")
        else:
            print(self.name, "je sám u", self.place.description)