
#odkazy na další soubory
from places import Places
from hero import Hero

# místa
hrad = Places("Strašidelný hrad")
Louka = Places("Loučka u studánky")
Les = Places("Strašidelný les")
rybnik = Places("Žužovej rybníček")
vesnice = Places("Oleška")

# propojení míst
hrad.umisti(None, None, Louka, None)
Louka.umisti(rybnik, None, None, hrad)
Les.umisti(vesnice, None, hrad, None)
rybnik.umisti(None, Louka, None, None)
vesnice.umisti(None, Les, None, None)

# hrdinové
hrdina1 = Hero(name="Drnec", race="Člověk", place=Les, job="Rytíř", health=100)
hrdina2 = Hero(name="Fidus", race="Elf", place=vesnice, job="Léčitel", health=90)

# výběr postavy
print("\nVyber si postavu:")
print("1 - Drnec (Člověk, Rytíř)")
print("2 - Fidus (Elf, Léčitel)")
volba = input("Zadej číslo (1 nebo 2): ").strip()
if volba == "1":
    aktivni_hrdina = hrdina1
elif volba == "2":
    aktivni_hrdina = hrdina2
else:
    print("Špatně, byl ti dán Drnec")
    aktivni_hrdina = hrdina1

# kde jsou
print("\nKde jste?")
hrdina1.kde_jsi()
hrdina2.kde_jsi()

# počáteční pohyb
hrdina1.jdi_na("zapad")
hrdina2.jdi_na("vychod")

hrdina1.kde_jsi()
hrdina2.kde_jsi()

# setkání
hrdina1.setkat_se()

# hlavní smyčka
while True:
    print("\nAktuální pozice postavy:")
    aktivni_hrdina.kde_jsi()

    akce = input("Co chceš dělat? (jdi/setkej/konec): ").strip().lower()

    if akce == "jdi":
        smer = input("Zadej směr (sever/vychod/jih/zapad): ").strip().lower()
        aktivni_hrdina.jdi_na(smer)
    elif akce == "setkej":
        aktivni_hrdina.setkat_se()
    elif akce == "konec":
        print("Konec hry.")
        break
    else:
        print("Zkus znovu.")
